export const COLORS=['#f2b544','#ed756d','#5dbeb0','#688ed6','#b58bdd','#e698c0','#99be60','#ed985b','#86c6db','#ece3c8'];
export const OUTFITS=['Mundu & shirt','Colour mundu','Kerala saree','Auto driver','Fisherman','Chenda artist','Police','Village youth'];
export const TASKS=[
{id:'tea',name:'Make chaya',ml:'ചായ ഉണ്ടാക്കുക',x:-13,z:-8,icon:'☕',steps:['Water','Tea','Milk','Sugar','Pour'],mlSteps:['വെള്ളം','തേയില','പാൽ','പഞ്ചസാര','ഒഴിക്കുക']},
{id:'fuse',name:'Repair the fuse',ml:'ഫ്യൂസ് ശരിയാക്കുക',x:12,z:-9,icon:'ϟ',steps:['Red','Blue','Yellow','Green']},
{id:'coconut',name:'Collect coconuts',ml:'തേങ്ങ ശേഖരിക്കുക',x:-19,z:5,icon:'◉',steps:['1','2','3','4','5']},
{id:'pump',name:'Repair water pump',ml:'പമ്പ് ശരിയാക്കുക',x:6,z:10,icon:'♒',steps:['Valve','Seal','Handle','Pump']},
{id:'chips',name:'Deliver banana chips',ml:'ചിപ്സ് എത്തിക്കുക',x:16,z:3,icon:'▱',steps:['Pack','Seal','Label','Deliver']},
{id:'festival',name:'Clean festival ground',ml:'ഉത്സവസ്ഥലം വൃത്തിയാക്കുക',x:1,z:-18,icon:'✦',steps:['1','2','3','4','5','6']},
{id:'boat',name:'Repair fishing boat',ml:'വള്ളം നന്നാക്കുക',x:-11,z:19,icon:'⚓',steps:['Plank','Nail','Pitch','Rope']}
];
export const BUILDINGS=[{x:-14,z:-13,w:8,d:6,color:0xeecb91,label:'CHAYA KADA'},{x:14,z:-15,w:9,d:6,color:0xf5e6c4,label:'THARAVADU'},{x:20,z:2,w:5,d:7,color:0xf2bd81,label:'CHIPS & MORE'},{x:-20,z:-23,w:6,d:5,color:0xa1d6c7,label:'VILLAGE HOME'},{x:20,z:19,w:7,d:5,color:0xedb2a1,label:'VILLAGE HOME'}];
export function walkable(x,z){return Math.abs(x)<27&&Math.abs(z)<27&&!BUILDINGS.some(b=>Math.abs(x-b.x)<b.w/2+.45&&Math.abs(z-b.z)<b.d/2+.45)&&!(z>22&&x<7);}
